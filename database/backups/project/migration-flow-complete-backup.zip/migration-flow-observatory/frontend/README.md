# Frontend — reservado para a etapa v1

Este módulo será implementado na etapa independente de **Frontend**, conforme definido em `docs/roadmap.md`.

A estrutura de pastas já reflete a arquitetura definida em `docs/architecture.md` e `docs/folder-structure.md`, e não deve ser alterada na implementação.
